MG30 Studio artwork baseline screenshot references

Extract this archive at the repository root. It contains eight original application screenshots renamed by model and organized into pedal/amplifier folders.
Target branch: feature/amp-knob-label-correction-artwork
